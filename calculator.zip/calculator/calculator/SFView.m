

#import "SFView.h"

@implementation SFView
//取给定视图的所有子视图，包括嵌套的子视图。
+ (NSArray *)allSubviews:(UIView *)viewSuper
{
    NSArray * arraySubview = viewSuper.subviews;
    for (UIView * subView in viewSuper.subviews)
    {
        NSArray * arraySub = [self allSubviews:subView];
        if (arraySub != nil)
        {
            arraySubview = [arraySubview arrayByAddingObjectsFromArray:arraySub];
        }
    }
    return arraySubview;
}

//给视图加圆角，默认为灰色线框。
/**
 * @brief    给视图加圆角，默认为灰色线框。
 * @param    view : 需要添加圆角的视图。
 */
+ (void)viewBounds:(UIView *)view
{
    CALayer * layer = [view layer];
    [layer setMasksToBounds:YES];
    [layer setCornerRadius:8.0f];
    [layer setBorderWidth:1.0f];
    [layer setBorderColor:[[UIColor grayColor] CGColor]];
}

//给视图加圆角，默认为灰色线框。
/**
 * @brief    给视图加圆角，默认为灰色线框。
 * @param    view : 需要添加圆角的视图。
 * @param    radius : 圆角半径 值越大 圆角越大。
 */
+ (void)viewBounds:(UIView *)view radius:(CGFloat)radius
{
    CALayer * layer = [view layer];
    [layer setMasksToBounds:YES];
    [layer setCornerRadius:radius];
    [layer setBorderWidth:1.0f];
    [layer setBorderColor:[[UIColor grayColor] CGColor]];
}

//给视图加圆角，只需要传入圆角大小 其他不改变
+ (void)viewBounds:(UIView *)view onlyRadius:(CGFloat)radius
{
    CALayer * layer = [view layer];
    [layer setMasksToBounds:YES];
    [layer setCornerRadius:radius];
}

//给视图加圆角。
/**
 * @brief    给视图加圆角。
 * @param    view : 需要添加圆角的视图。
 * @param    color : 线框的颜色。
 */
+ (void)viewBounds:(UIView *)view color:(UIColor *)color
{
    CALayer * layer = [view layer];
    [layer setMasksToBounds:YES];
    [layer setCornerRadius:5.0f];
    [layer setBorderWidth:1.0f];
    [layer setBorderColor:color.CGColor];
}

//给视图加圆角。
/**
 * @brief    给视图加圆角。
 * @param    view : 需要添加圆角的视图。
 * @param    color : 线框的颜色。
 * @param    radius : 圆角半径。值越大，圆角越大。
 */
+ (void)viewBounds:(UIView *)view color:(UIColor *)color radius:(CGFloat)radius
{
    CALayer * layer = [view layer];
    [layer setMasksToBounds:YES];
    [layer setCornerRadius:radius];
    [layer setBorderWidth:1.0f];
    [layer setBorderColor:color.CGColor];
}

//给视图加圆角。
/**
 * @brief    给视图加圆角。
 * @param    view : 需要添加圆角的视图。
 * @param    color : 线框的颜色。
 * @param    radius : 圆角半径。值越大，圆角越大。
 * @param    borderWidth : 线框宽度。
 */
+ (void)viewBounds:(UIView *)view color:(UIColor *)color radius:(CGFloat)radius borderWidth:(CGFloat)borderWidth
{
    CALayer * layer = [view layer];
    [layer setMasksToBounds:YES];
    [layer setCornerRadius:radius];
    [layer setBorderWidth:borderWidth];
    [layer setBorderColor:color.CGColor];
}

//视图抖动。
+ (void)viewShake:(UIView *)view
{
    CAKeyframeAnimation * animationKey = [CAKeyframeAnimation animationWithKeyPath:@"position"];
    [animationKey setDuration:0.5f];
    CGFloat offset = 10.0f;
    
    NSArray * array = [[NSArray alloc] initWithObjects:[NSValue valueWithCGPoint:CGPointMake(view.center.x - offset, view.center.y)], [NSValue valueWithCGPoint:CGPointMake(view.center.x + offset, view.center.y)], [NSValue valueWithCGPoint:CGPointMake(view.center.x - offset, view.center.y)], [NSValue valueWithCGPoint:CGPointMake(view.center.x + offset, view.center.y)], [NSValue valueWithCGPoint:CGPointMake(view.center.x - offset, view.center.y)], [NSValue valueWithCGPoint:CGPointMake(view.center.x + offset, view.center.y)], [NSValue valueWithCGPoint:CGPointMake(view.center.x - offset, view.center.y)], [NSValue valueWithCGPoint:CGPointMake(view.center.x + offset, view.center.y)], [NSValue valueWithCGPoint:CGPointMake(view.center.x - offset, view.center.y)], [NSValue valueWithCGPoint:CGPointMake(view.center.x + offset, view.center.y)], nil];
    [animationKey setValues:array];
    
    NSArray * times = [[NSArray alloc] initWithObjects:[NSNumber numberWithFloat:0.1f], [NSNumber numberWithFloat:0.2f], [NSNumber numberWithFloat:0.3f], [NSNumber numberWithFloat:0.4f], [NSNumber numberWithFloat:0.5f], [NSNumber numberWithFloat:0.6f], [NSNumber numberWithFloat:0.7f], [NSNumber numberWithFloat:0.8f], [NSNumber numberWithFloat:0.9f], [NSNumber numberWithFloat:1.0f], nil];
    [animationKey setKeyTimes:times];
    
    [view.layer addAnimation:animationKey forKey:nil];
}

//计算label宽高。
/**
 * @brief    。
 * @param    label : 需要计算的label。
 */
+ (CGSize)labelString:(NSString *)text maxSize:(CGSize )maxSize font:(CGFloat )font{
        NSDictionary *attribute = @{NSFontAttributeName: [UIFont systemFontOfSize:font]};
        CGSize labelSize = [text boundingRectWithSize:maxSize options: NSStringDrawingTruncatesLastVisibleLine | NSStringDrawingUsesLineFragmentOrigin | NSStringDrawingUsesFontLeading attributes:attribute context:nil].size;
    return labelSize;
}


@end
