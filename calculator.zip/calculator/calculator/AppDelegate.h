//
//  AppDelegate.h
//  calculator
//
//  Created by 乔小乔 on 2018/3/25.
//  Copyright © 2018年 乔小乔. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

