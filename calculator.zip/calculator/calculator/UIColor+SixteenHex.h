

#import <UIKit/UIKit.h>

@interface UIColor (SixteenHex)

+(UIColor *)colorWithSixteenHex:(NSInteger)hex;
@end
