

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
@interface SFView : NSObject
//取给定视图的所有子视图，包括嵌套的子视图。
/**
 * @brief    取给定视图的所有子视图，包括嵌套的子视图。
 * @param    viewSuper : 取该视图下的子视图。
 * @return   子视图数组。
 */
+ (NSArray *)allSubviews:(UIView *)viewSuper;

//给视图加圆角，默认为灰色线框。
/**
 * @brief    给视图加圆角，默认为灰色线框。
 * @param    view : 需要添加圆角的视图。
 */
+ (void)viewBounds:(UIView *)view;

//给视图加圆角，默认为灰色线框。
/**
 * @brief    给视图加圆角，默认为灰色线框。
 * @param    view : 需要添加圆角的视图。
 * @param    radius : 圆角半径 值越大 圆角越大。
 */
+ (void)viewBounds:(UIView *)view radius:(CGFloat)radius;

//给视图加圆角，只需要传入圆角大小 其他不改变
/**
 * @brief    给视图加圆角，只需要传入圆角大小 其他不改变
 * @param    view : 需要添加圆角的视图。
 * @param    radius : 圆角半径 值越大 圆角越大。
 */
+ (void)viewBounds:(UIView *)view onlyRadius:(CGFloat)radius;

//给视图加圆角。
/**
 * @brief    给视图加圆角。
 * @param    view : 需要添加圆角的视图。
 * @param    color : 线框的颜色。
 */
+ (void)viewBounds:(UIView *)view color:(UIColor *)color;

//给视图加圆角。
/**
 * @brief    给视图加圆角。
 * @param    view : 需要添加圆角的视图。
 * @param    color : 线框的颜色。
 * @param    radius : 圆角半径。值越大，圆角越大。
 */
+ (void)viewBounds:(UIView *)view color:(UIColor *)color radius:(CGFloat)radius;

//给视图加圆角。
/**
 * @brief    给视图加圆角。
 * @param    view : 需要添加圆角的视图。
 * @param    color : 线框的颜色。
 * @param    radius : 圆角半径。值越大，圆角越大。
 * @param    borderWidth : 线框宽度。
 */
+ (void)viewBounds:(UIView *)view color:(UIColor *)color radius:(CGFloat)radius borderWidth:(CGFloat)borderWidth;

//视图抖动。
/**
 * @brief    视图抖动。
 * @param    view : 需要抖动的视图。
 */
+ (void)viewShake:(UIView *)view;

//计算label宽高。
/**
 * @brief    。
 * @param    label : 需要计算的label。
 */
+ (CGSize)labelString:(NSString *)text maxSize:(CGSize )maxSize font:(CGFloat )font;


@end
