

#import <UIKit/UIKit.h>

@interface UIView (Frame)
/**
 * @brief    属性，位置，等于view.frame.origin。
 */
@property (nonatomic, assign) CGPoint point;

/**
 * @brief    属性，大小，等于view.frame.size。
 */
@property (nonatomic, assign) CGSize size;

/**
 * @brief    属性，宽度，等于view.frame.size.width。
 */
@property (nonatomic, assign) CGFloat width;

/**
 * @brief    属性，高度，等于view.frame.size.height。
 */
@property (nonatomic, assign) CGFloat height;

/**
 * @brief    属性，左边距，等于view.frame.origin.x。
 */
@property (nonatomic, assign) CGFloat left;

/**
 * @brief    属性，上边距，等于view.frame.origin.y。
 */
@property (nonatomic, assign) CGFloat top;

/**
 * @brief    属性，X轴中心位置。
 */
@property (nonatomic, assign) CGFloat centerX;

/**
 * @brief    属性，Y轴中心位置。
 */
@property (nonatomic, assign) CGFloat centerY;

//清空View上的所有控件
/**
 * @brief    清空View上的所有控件
 */
-(void)clearAllSubViews;
@end
