//
//  ViewControllerQuickReceipts.m
//  DinnerManage
//
//  Created by 乔小乔 on 2018/1/18.
//  Copyright © 2018年 jiangjun. All rights reserved.
//

//UIScreen
#define kWidthScreen      [[UIScreen mainScreen] bounds].size.width
#define kHeightScreen     [[UIScreen mainScreen] bounds].size.height
#define kHeightStatusBar  [[UIApplication sharedApplication] statusBarFrame].size.height
#define kHeightNavigation self.navigationController.navigationBar.frame.size.height
#define kHeightUnlessNav kHeightScreen - kHeightNavigation - kHeightStatusBar

#define kSFScale kWidthScreen/375.0f
#import "ViewControllerQuickReceipts.h"
#import "SFView.h"
#import "UIColor+SixteenHex.h"
#import "UIView+Frame.h"
@interface ViewControllerQuickReceipts ()<UIScrollViewDelegate>
{
    __weak IBOutlet UIScrollView *scrollView;
    __weak IBOutlet NSLayoutConstraint *layoutHeight;
    __weak IBOutlet NSLayoutConstraint *layoutWidth;
    __weak IBOutlet UIView *viewKeyBord;
    __weak IBOutlet UIView *viewAmount;
//    计算结果
    __weak IBOutlet UILabel *labelReault;
//    计算过程
    __weak IBOutlet UILabel *labelProcess;

    NSArray * arrayKeyBord;
//    键盘上的金额字段
    UILabel *labelDiscount;
    UILabel *lableRecevieAmount;
//    计算过程，长字符串
    NSMutableString * strProcess;
//    数字数组
    NSMutableArray * arrayNumbers;
//    当前证输入数字
    NSMutableString *strCurrentNumber;
//    优惠金额,以下三个都是元为单位，跟后台交互时应*100
    double discountAmount;
//    应收金额
    double recevieAmount;
//    总金额
    double subAmount;
    
}
@end

@implementation ViewControllerQuickReceipts

#pragma mark --计算器实现部分--
-(void)createUI{
//    上下左右间隔为15，宽度为75,高50
    arrayKeyBord=@[@"7",@"8",@"9",@"4",@"5",@"6",@"1",@"2",@"3",@"00",@"0",@"·"];
    for (int i=0; i<12; i++) {
        UIButton *button=[UIButton buttonWithType:UIButtonTypeCustom];
        
        button.frame=CGRectMake(15*kSFScale+i%3*90*kSFScale, 15*kSFScale+i/3*65*kSFScale, 75*kSFScale, 50*kSFScale);
        [SFView viewBounds:button color:[UIColor colorWithSixteenHex:0xE45662] radius:2.5*kSFScale borderWidth:0.5];
        [button setTitle:arrayKeyBord[i] forState:UIControlStateNormal];
        button.titleLabel.font=[UIFont systemFontOfSize:24*kSFScale];
        [button setTitleColor:[UIColor colorWithSixteenHex:0x333333] forState:UIControlStateNormal];
        [viewKeyBord addSubview:button];
        [button addTarget:self action:@selector(clickNumber:) forControlEvents:UIControlEventTouchUpInside];
    }
    NSArray * arrayPic=@[@"receive_back",@"receive_add"];
    for (int i=0; i<2; i++) {
        UIButton *button=[UIButton buttonWithType:UIButtonTypeCustom];
        button.frame=CGRectMake(285*kSFScale, 15*kSFScale+i*65*kSFScale, 75*kSFScale, 50*kSFScale);
        [SFView viewBounds:button color:[UIColor colorWithSixteenHex:0xE45662] radius:2.5*kSFScale borderWidth:0.5];
        button.tag=i+2000;
        UIImageView *imagePic=[[UIImageView alloc]init];
        imagePic.image=[UIImage imageNamed:arrayPic[i]];
        imagePic.size=CGSizeMake(20*kSFScale, 20*kSFScale);
        imagePic.center=button.center;
        [viewKeyBord addSubview:imagePic];
        [viewKeyBord addSubview:button];
        [button addTarget:self action:@selector(clickSymbol:) forControlEvents:UIControlEventTouchUpInside];
    }
    NSArray * btnTitle=@[@"选择优惠",@"收款"];
    for (int i=0; i<2; i++) {
        UIButton *button=[UIButton buttonWithType:UIButtonTypeCustom];
        button.frame=CGRectMake(285*kSFScale, 145*kSFScale+i*65*kSFScale, 75*kSFScale, 50*kSFScale);
        [SFView viewBounds:button color:[UIColor colorWithSixteenHex:0xE45662] radius:2.5*kSFScale borderWidth:0.5];
        [button setTitle:btnTitle[i] forState:UIControlStateNormal];
        button.titleLabel.font=[UIFont systemFontOfSize:15*kSFScale];
        if (i==0) {
            [button setTitleColor:[UIColor colorWithSixteenHex:0xE45662] forState:UIControlStateNormal];
        }else{
            button.backgroundColor=[UIColor colorWithSixteenHex:0xE45662];
            [button setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        }
        button.tag=i+3000;
        [viewKeyBord addSubview:button];
        [button addTarget:self action:@selector(clickFunction:) forControlEvents:UIControlEventTouchUpInside];
    }
    
    UILabel *label1=[[UILabel alloc]initWithFrame:CGRectMake(15*kSFScale, 0, 59*kSFScale, 43*kSFScale)];
    label1.text=@"优惠金额";
    label1.font=[UIFont systemFontOfSize:12*kSFScale];
    label1.textColor=[UIColor colorWithSixteenHex:0x333333];
    [viewAmount addSubview:label1];
    labelDiscount=[[UILabel alloc]initWithFrame:CGRectMake(74*kSFScale, 0, 122*kSFScale, 43*kSFScale)];
    labelDiscount.font=[UIFont systemFontOfSize:15*kSFScale];
    labelDiscount.textColor=[UIColor colorWithSixteenHex:0xE45662];
    labelDiscount.text=@"￥0.00";
    
    UILabel *label2=[[UILabel alloc]initWithFrame:CGRectMake(195*kSFScale, 0, 59*kSFScale, 43*kSFScale)];
    label2.text=@"应收金额";
    label2.font=[UIFont systemFontOfSize:12*kSFScale];
    label2.textColor=[UIColor colorWithSixteenHex:0x333333];
    
    lableRecevieAmount=[[UILabel alloc]initWithFrame:CGRectMake(254*kSFScale, 0, 106*kSFScale, 43*kSFScale)];
    lableRecevieAmount.font=[UIFont systemFontOfSize:15*kSFScale];
    lableRecevieAmount.textColor=[UIColor colorWithSixteenHex:0xE45662];
    lableRecevieAmount.text=@"￥0.00";
    
    [viewAmount addSubview:label1];
    [viewAmount addSubview:label2];
    [viewAmount addSubview:labelDiscount];
    [viewAmount addSubview:lableRecevieAmount];
    
}
-(void)clickNumber:(UIButton *)sender{
    NSString *str= sender.currentTitle;
    if ([str isEqualToString:@"·"]) {
        str=@".";
    }
    [self judgeCanInput:str];
}
-(void)clickSymbol:(UIButton *)sender{
    if (strProcess.length<=0) {
        return;
    }
    NSInteger index=sender.tag-2000;
    if (index==0) {
//        删除一位
//        先判断最后一位是不是“+”，是加号的话删除+，然后把最后一个数取出来，数组删掉最后一个数
        if ([strProcess hasSuffix:@"+"]) {
            [strCurrentNumber setString:arrayNumbers.lastObject];
            [arrayNumbers removeObjectAtIndex:arrayNumbers.count-1];
        }else{
//            如果不是加号，则吧当前数删掉最后一位
            [strCurrentNumber deleteCharactersInRange:NSMakeRange(strCurrentNumber.length-1, 1)];
        }
        [strProcess deleteCharactersInRange:NSMakeRange(strProcess.length-1, 1)];
        [self disposeTheNumber];
    }else{
//        加号
        NSString *str=@"+";
        [self judgeCanInput:str];
    }
}
//判断是否可以输入
-(void)judgeCanInput:(NSString *)str{
    BOOL isAppend=NO;
    BOOL canInputNumber = [self judgePoint:2];
    if ([str isEqualToString:@"."]) {
//        如果当前数刚要输入时，“.”前默认加0
        if (strCurrentNumber.length==0) {
            str=@"0.";
            [strCurrentNumber appendString:str];
            isAppend=YES;
        }else{
//            如果没有输入过
            if ([strCurrentNumber rangeOfString:@"."].length == 0) {
                [strCurrentNumber appendString:str];
                isAppend=YES;
            }
        }
    }else if ([str isEqualToString:@"0"]){
//        判断是否只有一位且是0,不是的话继续判断室友有小数点影响输入
        if (![strCurrentNumber isEqualToString:@"0"]) {
            if (canInputNumber) {
                [strCurrentNumber appendString:str];
                isAppend=YES;
            }
        }
        
    }else if ([str isEqualToString:@"00"]){
//        不能以00开头，所以要判断是否是首位
        if (strCurrentNumber.length>0&&![strCurrentNumber isEqualToString:@"0"]) {
            canInputNumber=[self judgePoint:1];
//            可以输入
            if (canInputNumber) {
                [strCurrentNumber appendString:str];
                isAppend=YES;
            }
        }
        
    }else if ([str isEqualToString:@"+"]){
//        判断字符串最后一位是不是加号,不是的话，将当前数字加入数组并设置为空
        if (![strProcess hasSuffix:@"+"]) {
//            如果最后一位是. 将长字符串这个点去掉
            if ([strCurrentNumber hasSuffix:@"."]) {
                [strProcess deleteCharactersInRange:NSMakeRange(strProcess.length-1, 1)];
            }
            NSString * str=[strCurrentNumber copy];
            [arrayNumbers addObject:str];
            [strCurrentNumber setString:@""];
            isAppend=YES;
        }
    }else{
//        如果首位是0则重置，并且将长字符串最后一位删除
        if ([strCurrentNumber isEqualToString:@"0"]) {
            [strCurrentNumber setString:str];
            [strProcess deleteCharactersInRange:NSMakeRange(strProcess.length-1, 1)];
            isAppend=YES;
        }else{
            if (canInputNumber) {
                [strCurrentNumber appendString:str];
                isAppend=YES;
            }
        }
    }
    
//    如果可以输入则叠加字符串
    if (isAppend) {
        [strProcess appendString:str];
        [self disposeTheNumber];
    }
}
-(BOOL)judgePoint:(NSInteger)limited{
//    limited 代表小数点后还可输入几个数
//    先判断有没有输入过"."
//    没有的话,返回是，说明可以输入数字
    if ([strCurrentNumber rangeOfString:@"."].length == 0) {
        return YES;
    }else{
//        有的话，看是否允许继续输入数字
        if (strCurrentNumber.length-1<=limited) {
            return YES;
        }
        for (NSInteger i=strCurrentNumber.length-1; i>=0; i--) {
            if ([strCurrentNumber characterAtIndex:i] == '.') {
                if (i > strCurrentNumber.length-1-limited) {
                    return YES;
                }
                break;
            }
        }
    }
    return NO;
}

-(void)disposeTheNumber{
//    在这里，当前输入数字已经处理过无需处理
    labelProcess.text=strProcess;
    double totalNumber=0;
    for (int i=0; i<arrayNumbers.count; i++) {
        NSString * str=arrayNumbers[i];
        totalNumber+=str.doubleValue;
    }
    totalNumber=totalNumber+strCurrentNumber.doubleValue;
    if (subAmount!=totalNumber) {
        subAmount=totalNumber;
    }
    labelReault.text=[NSString stringWithFormat:@"%.2f",totalNumber];
    recevieAmount=subAmount-discountAmount;
    lableRecevieAmount.text=[NSString stringWithFormat:@"￥%.2f",recevieAmount];
    labelDiscount.text=[NSString stringWithFormat:@"￥%.2f",discountAmount];
}
-(void)clickFunction:(UIButton *)sender{
    NSInteger index=sender.tag-3000;
    if (index==0) {
        
    }else{
        
    }
}
#pragma mark system
- (void)viewDidLoad {
    [super viewDidLoad];
    self.navigationItem.title=@"快捷收款";
    strProcess=[[NSMutableString alloc]init];
    strCurrentNumber=[[NSMutableString alloc]init];
    arrayNumbers=[[NSMutableArray alloc]init];
    [self createUI];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)updateViewConstraints{
    [super updateViewConstraints];
    layoutWidth.constant=kWidthScreen;
    layoutHeight.constant=kHeightUnlessNav;
}

@end
