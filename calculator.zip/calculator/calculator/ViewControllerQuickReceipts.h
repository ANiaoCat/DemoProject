//
//  ViewControllerQuickReceipts.h
//  DinnerManage
//
//  Created by 乔小乔 on 2018/1/18.
//  Copyright © 2018年 jiangjun. All rights reserved.
//

//#import "UIViewControllerBase.h"
#import <UIKit/UIKit.h>
@interface ViewControllerQuickReceipts : UIViewController

@end
