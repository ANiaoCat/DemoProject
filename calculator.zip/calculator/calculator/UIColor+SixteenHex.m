
#import "UIColor+SixteenHex.h"

@implementation UIColor (SixteenHex)
+(UIColor *)colorWithSixteenHex:(NSInteger)hex
{
    UIColor * colorResult = [UIColor colorWithRed:(float)((hex & 0xFF0000) >> 16) / 255.0f green:(float)((hex & 0xFF00) >> 8) / 255.0f blue:(float)(hex & 0xFF) / 255.0f alpha:1.0f];
    return colorResult;
}
@end
